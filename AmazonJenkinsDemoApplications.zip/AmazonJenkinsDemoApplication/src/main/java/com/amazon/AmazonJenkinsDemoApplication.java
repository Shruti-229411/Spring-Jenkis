package com.amazon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmazonJenkinsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmazonJenkinsDemoApplication.class, args);
	}

}
